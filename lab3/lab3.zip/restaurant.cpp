#include <iostream>
#include "restaurant.h"

string Restaurant::get_name() {
    return name;
}

void Restaurant::set_name(string n){
    name = n;
}

