using namespace std;

#include <string>
struct student{
    int idNum;
    char* fname;
    char* lname;
    char* major;
    char* students[];
};